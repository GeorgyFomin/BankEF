﻿using System;

namespace Domain.Model
{
    public class Guided
    {
        public Guid Id { get; set; }
    }
}
